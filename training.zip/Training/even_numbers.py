def isEven(number):
    """
    :param number: number to check for even
    :return: True if number is even else False
    """
    if number % 2 == 0:
        return True
    else:
        return False

if __name__ == "__main__":
    print(list(filter(isEven,range(1,50))))
    print(isEven.__doc__)