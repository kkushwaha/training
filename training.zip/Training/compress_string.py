#!/usr/bin/python
import argparse
import re

if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument('--string',
                        type=str,
                        help='Please specify the string to compress.'
                        )


    args = parser.parse_args()

    #print("Operating System: {}".format(args.os))
    print("User Provided String: {}".format(args.string))
    if re.search(r'\s|\d',args.string):
        print("Invalid String. Having Spaces or digit")

    else:
        uniqChar = []
        for i in list(args.string):
            if i not in uniqChar:
                uniqChar.append(i)

        print("Unique Characters: {}".format(uniqChar))
        result = []
        for i in uniqChar:
            result.append(i)
            result.append('{}'.format(args.string.count(i)))

        print("Result: {}".format(''.join(result)))
