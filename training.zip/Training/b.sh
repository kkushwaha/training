#!/usr/bin/python

print("hello world")
list1=range(10)
print("List {}".format(list1))
