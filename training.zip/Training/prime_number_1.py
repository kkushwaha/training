#!/usr/bin/python

def isPrime(number):
    for value in range(2,int(number/2)+1):
        if number % value == 0:
            return False
    return True

print(list(filter(isPrime,range(2,100))))