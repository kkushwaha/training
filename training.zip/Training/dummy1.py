def isPrime(number):
    #Write logic to check whether number is prime or not
    #Function should return True if number is Prime else False
    for value in range(2,int(number/2)+1):
        if number % value == 0:
            return False
    return True



if __name__ == "__main__":
    print(list(filter(isPrime,range(2,500))))
